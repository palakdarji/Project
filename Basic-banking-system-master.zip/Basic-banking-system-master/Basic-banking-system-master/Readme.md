# Basic banking system

This Repo showcases my project, that I've created for my Internship task at The Sparks Foundation.

I'm hosting this project at Heroku.
Only PC view is available for now. <br>
If you're using a mobile, please come back later as I'm adding CSS queries soon!<br>

Go to https://basic-banking-system.herokuapp.com/ to see this project live.

## How to start:

1. Clone my repository or download the zip file
2. If you're downloading the zip file, extract the zip file to a folder
3. Open the folder with a code editor like VS Code or any IDE.
4. Create two tables in a database - One to store user details and one to store transaction details. 
5. Create the necessery columns.
6. Update my Config.php file with your database details.
7. Run the code with XAAMP. You can reach out to me for queries. Details in my profile readme.

### Happy coding!

 
